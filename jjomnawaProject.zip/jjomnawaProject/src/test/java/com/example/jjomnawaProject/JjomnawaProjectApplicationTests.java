package com.example.jjomnawaProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JjomnawaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
